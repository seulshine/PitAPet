package com.example.jpetstore.domain;

public class Note {
	
	private String noteId; //�⺻Ű
	private String date;
	private String message;
	private String sender;
	private String receiver;
	private boolean sendCheck; //���� ���ſ���
	private String time; // �ð�
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public boolean isSendCheck() {
		return sendCheck;
	}
	public void setSendCheck(boolean sendCheck) {
		this.sendCheck = sendCheck;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
}
