package com.example.jpetstore.service;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.example.jpetstore.domain.*;

/**
 * JPetStore's central business interface.
 *
 * @author Juergen Hoeller
 * @since 30.11.2003
 */
public interface PitAPetFacade {
	
	//AccountDao
	Account getAccount(String username);

	Account getAccount(String username, String password);

	void insertAccount(Account account);

	void updateAccount(Account account);
	void deleteAccount(Account account);
	
	List<String> getUsernameList();

    //CategoryDao
	List<Category> getCategoryList();

	Category getCategory(String categoryId);
	
	
	//ItemDao

	
	  public void updateInventoryQuantity(Map<String, Object> param);  //GoodsItemDao�� ���� �̿�

	  public int getInventoryQuantity(String itemId); //GoodsItemDao�� ���� �̿�


	  public List<Item> getItemListByProduct(String productId);

	  public Item getItem(String itemId);
	  
	  public boolean isItemInStock(String itemId);


	  public void insertItem(Item item) throws DataAccessException;


	  public void deleteItem(Item item) throws DataAccessException;
	  
	  
	//GoodsItemDao


	  public List<GoodsItem> getGoodsItemListByProduct(String goodsProductId) throws DataAccessException;
	  public GoodsItem getGoodsItem(String goodsItemId) throws DataAccessException;
	  
	  public void insertGoodsItem(GoodsItem goodsItem) throws DataAccessException;

	  public void deleteGoodsItem(GoodsItem goodsItem) throws DataAccessException;
	  
	
	// CartDao
	  List<GoodsItem> getGoodsItemByUsername(String username);

	 void insertGoodsItemToCart(GoodsItem goodsItem, String username);

	void deleteGoodsItemInCart(GoodsItem goodsItem, String username);
	
	

	//GoodsProductDao
	List<GoodsProduct> getGoodsProductListByCategory(String goodsCategoryId);
	
	List<GoodsProduct> searchGoodsProductList(String keywords);
	
	GoodsProduct getGoodsProduct(String goodsProductId);
		
   //ProductDao
	List<Product> getProductListByCategory(String categoryId);

	List<Product> searchProductList(String keywords);

	Product getProduct(String productId);

	

	
	//AuctionDao
	
	  List<Auction> getAuctionsByCategoryId(String categoryId);

	  List<Auction> getAuctionsByProductId(String categoryId, String ProductId);

	  List<Auction> getMadeAuctionsByUsername(String username);

	  Auction getMadeAuction(int auctionId, String username);

	void makeAuction(Auction auction);

	void deleteAuction(Auction auction);

	  List<Auction> getTendersByUsername(String username);

	  Auction getTenders(int auctionId);

	  void insertTender(Bid tender) ;

	//OrderDao
	void insertOrder(Order order, String username);
	void deleteOrder(Order order);
	Order getOrder(int orderId);

	List<Order> getOrdersByUsername(String username);
	
	
	
	//DiaryDao
	

	  Diary getDiary(String username, String petname, String date);

	  void insertDiaryList(String petName, String diaryTitle, String username);

	  List<Diary> getDiaryList(String username);

	  void insertDiary(Diary diary, String username, String petname);

	  void updateDiary(Diary diary, String username, String petname);

	  void deleteDiary(Diary diary, String username);
	  
	  
	  

	  //CouponDao
	  
	  Coupon getCoupon(String username, String couponId);

	    void issueCoupon(Coupon coupon, String username);
	    void deleteCoupon(String couponId, String username);
	    List<Coupon> getCouponList(String username) ;
	  
	  
	    
	    //NoteDao
	    
	    void sendNote(Note note);

	    void deleteNote(String noteId, String username);

	    List<Note> getNoteList(String username);

	    void selectNote(String noteId, String username) ;

	    List<Note> searchNoteList(String username) ;

	  

}