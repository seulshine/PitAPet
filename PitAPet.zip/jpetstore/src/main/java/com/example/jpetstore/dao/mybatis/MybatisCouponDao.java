package com.example.jpetstore.dao.mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.example.jpetstore.dao.mybatis.mapper.CouponMapper;
import com.example.jpetstore.domain.Coupon;

@Repository
public class MybatisCouponDao {
	
	@Autowired
	private CouponMapper couponMapper;

	// ���� ������ �����ֱ�
	public Coupon getCoupon(String username, String couponId) throws DataAccessException {
		return couponMapper.getCoupon(username, couponId);
	}

	 // ��������
	 public void issueCoupon(Coupon coupon, String username) throws DataAccessException{
		 couponMapper.issueCoupon(coupon, username);
	 }

	// ���� ����
	 public void deleteCoupon(String couponId, String username) throws DataAccessException {
		 couponMapper.deleteCoupon(couponId, username);
	 }

	// ���� ����Ʈ ��������
	 public List<Coupon> getCouponList(String username) throws DataAccessException{
		 return couponMapper.getCouponList(username);
	 }
	 
	  
}
