package com.example.jpetstore.domain;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.support.PagedListHolder;


//īƮ ���� �պ����� �ߴµ� ��Ƴ� �Ф� cartItem���� goodsItem �̶� item�̶� ���� ������ ��������! ����� ������ �����ؼ� �Ȱ��� �ϸ� �ɰͰ���! - ����
//Lineitem�� �ٲ�� �ϴ���!! db�� lineitem�� �߰��߾�~ �ʿ��Ѱ� ���Ƽ�!
@SuppressWarnings("serial")
public class Cart implements Serializable {
	
	private String cartId;
	private String itemId;
	private String quantity;
	private String inStock;
	private String listPrice;
	private String totalCost;
	private String descn;
	private String username;
	
	
	


	  /* Private Fields */

	  public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getInStock() {
		return inStock;
	}

	public void setInStock(String inStock) {
		this.inStock = inStock;
	}

	public String getListPrice() {
		return listPrice;
	}

	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}

	public String getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}

	public String getDescn() {
		return descn;
	}

	public void setDescn(String descn) {
		this.descn = descn;
	}

	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

	
	
	
	
	
	//������ �ڵ� �̰� �����ؼ� ��Ʈ�ѷ� �����ϸ� �ɰͰ���!
	public Map<String, CartItem> getItemMap() {
		return itemMap;
	}

	public PagedListHolder<CartItem> getItemList() {
		return itemList;
	}

	private final Map<String, CartItem> itemMap = Collections.synchronizedMap(new HashMap<String, CartItem>());
		
	  private final PagedListHolder<CartItem> itemList = new PagedListHolder<CartItem>();

	  /* JavaBeans Properties */

		public Cart() {
			this.itemList.setPageSize(4);
		}

		public Iterator<CartItem> getAllCartItems() { return itemList.getSource().iterator(); }
	  public PagedListHolder<CartItem> getCartItemList() { return itemList; }
	  public int getNumberOfItems() { return itemList.getSource().size(); }

	  /* Public Methods */

	  public boolean containsItemId(String itemId) {
	    return itemMap.containsKey(itemId);
	  }

	  public void addItem(Item item, boolean isInStock) {
	    CartItem cartItem = itemMap.get(item.getItemId());
	    if (cartItem == null) {
	      cartItem = new CartItem();
	      cartItem.setItem(item);
	      cartItem.setQuantity(0);
	      cartItem.setInStock(isInStock);
	      itemMap.put(item.getItemId(), cartItem);
	      itemList.getSource().add(cartItem);
	    }
	    cartItem.incrementQuantity();
	  }


	  public Item removeItemById(String itemId) {
	    CartItem cartItem = itemMap.remove(itemId);
	    if (cartItem == null) {
	      return null;
	    }
			else {
	      itemList.getSource().remove(cartItem);
	      return cartItem.getItem();
	    }
	  }

	  public void incrementQuantityByItemId(String itemId) {
	    CartItem cartItem = itemMap.get(itemId);
	    cartItem.incrementQuantity();
	  }

	  public void setQuantityByItemId(String itemId, int quantity) {
	    CartItem cartItem = itemMap.get(itemId);
	    cartItem.setQuantity(quantity);
	  }

	  public double getSubTotal() {
	    double subTotal = 0;
	    Iterator<CartItem> items = getAllCartItems();
	    while (items.hasNext()) {
	      CartItem cartItem = (CartItem) items.next();
	      Item item = cartItem.getItem();
	      double listPrice = item.getListPrice();
	      int quantity = cartItem.getQuantity();
	      subTotal += listPrice * quantity;
	    }
	    return subTotal;
	  }


}
