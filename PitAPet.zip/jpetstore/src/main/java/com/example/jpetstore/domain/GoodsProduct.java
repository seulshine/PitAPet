package com.example.jpetstore.domain;

public class GoodsProduct {
	
	private String goodsProductId;
	private String goodsCategoryId;
	private String name;
	private String description;
	
	public GoodsProduct() {
		
	}
}
