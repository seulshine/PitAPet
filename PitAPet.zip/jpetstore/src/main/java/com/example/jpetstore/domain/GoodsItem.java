package com.example.jpetstore.domain;

public class GoodsItem {
	private String goodsItemId;
	private String goodsProductId;
	private double price;
	private String content;
	private String image;
	private String supplier;
	private GoodsProduct goodsProduct;
	private int quantity;
	

	public String getGoodsItemId() {
		return goodsItemId;
	}

	public String getGoodsProductId() {
		return goodsProductId;
	}

	public void setGoodsProductId(String goodsProductId) {
		this.goodsProductId = goodsProductId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public GoodsProduct getGoodsProduct() {
		return goodsProduct;
	}

	public void setGoodsProduct(GoodsProduct goodsProduct) {
		this.goodsProduct = goodsProduct;
	}

	public void setGoodsItemId(String goodsItemId) {
		this.goodsItemId = goodsItemId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	
	


	
	
}
