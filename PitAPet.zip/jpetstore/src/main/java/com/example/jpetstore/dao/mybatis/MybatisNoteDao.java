package com.example.jpetstore.dao.mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.example.jpetstore.dao.mybatis.mapper.NoteMapper;
import com.example.jpetstore.domain.Note;

@Repository
public class MybatisNoteDao {

	@Autowired
	private NoteMapper noteMapper;
	
	 // ��������
	 public void sendNote(Note note) throws DataAccessException {
		 noteMapper.sendNote(note);
	  }

	// ���� ����
	  public void deleteNote(String noteId, String username) throws DataAccessException {
		  noteMapper.deleteNote(noteId, username);
	  }

	// ���� ���
	  public List<Note> getNoteList(String username) throws DataAccessException {
		 return noteMapper.getNoteList(username);
	  }

	// ���� ����
	  public Note selectNote(String noteId, String username) throws DataAccessException {
		  return noteMapper.selectNote(noteId, username);
	  }

	// ���� �˻�
	  public List<Note> searchNoteList(String username) throws DataAccessException {
		  return noteMapper.searchNoteList(username);
	  }
}
