package com.example.jpetstore.domain;

public class Coupon {
	
	private String couponId;
	private String couponName;
	private Account username; //�ܷ�Ű
	private String issue; //�߱���
	private String expire; //��ȿ�Ⱓ
	private int discount; //���ΰ�
	
	public Coupon() {
		
	}
}
