package com.example.jpetstore.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.example.jpetstore.domain.Item;
import com.example.jpetstore.domain.Order;

public interface ItemDao {

	  void updateInventoryQuantity(Map<String, Object> param);
	  
	  //void updateQuantity(Order order);
	  
	  int getInventoryQuantity(String itemId);

	  List<Item> getItemListByProduct(String productId);

	  Item getItem(String itemId);
	  
	  boolean isItemInStock(String itemId);

	  //�Ǹž��ڰ� ��ǰ�� �ø�
	  void insertItem(Item item) throws DataAccessException;

	  //�Ǹž��ڰ� ��ǰ�� ����
	  void deleteItem(Item item) throws DataAccessException;

}
