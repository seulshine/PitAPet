package com.example.jpetstore.domain;

public class GoodsCategory {
	private String goodsCategoryId;
	private String name;
	private String description;
	
	public GoodsCategory() {
		
	}
}
