package com.example.jpetstore.dao.mybatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.example.jpetstore.dao.mybatis.mapper.GoodsItemMapper;
import com.example.jpetstore.domain.GoodsItem;
import com.example.jpetstore.domain.LineItem;
import com.example.jpetstore.domain.Order;

@Repository
public class MybatisGoodsItemDao {

	@Autowired
	private GoodsItemMapper goodsItemMapper;

	

	// 	public void updateInventoryQuantity(Map<String, Object> param)  �̰� �����ؼ��� ���� ���� ������ �˰Ͱ��Ƽ� �ϴ� �� �Լ��� ���� ����~!
	public void updateQuantity(Order order) throws DataAccessException {
		for (int i = 0; i < order.getLineItems().size(); i++) {
			LineItem lineItem = (LineItem) order.getLineItems().get(i);
			String goodsItemId = lineItem.getItemId();
			Integer increment = new Integer(lineItem.getQuantity());
			Map<String, Object> param = new HashMap<String, Object>(2);
			param.put("goodsItemId", goodsItemId);
			param.put("increment", increment);
			goodsItemMapper.updateInventoryQuantity(param);
		}
	}
	
	public int getInventoryQuantity(String itemId) {
		return goodsItemMapper.getInventoryQuantity(itemId);
	}


	public boolean isItemInStock(String goodsItemId) throws DataAccessException {
		return (goodsItemMapper.getInventoryQuantity(goodsItemId) > 0);
	}

	//Prdouct �� �´� GoodsItem�� �ҷ���
	 public List<GoodsItem> getGoodsItemListByProduct(String goodsProductId) throws DataAccessException {
		  return goodsItemMapper.getGoodsItemListByProduct(goodsProductId);
	  }

	//������ GoodsId���´� item�ҷ���
	public  GoodsItem getGoodsItem(String goodsItemId) throws DataAccessException {
		return goodsItemMapper.getGoodsItem(goodsItemId);
	}


	//�Ǹž��ڰ� ��ǰ�� �ø�
	public  void insertGoodsItem(GoodsItem goodsItem) throws DataAccessException {
		goodsItemMapper.insertGoodsItem(goodsItem);
	}


	//�Ǹž��ڰ� ��ǰ�� ����
	 public void deleteGoodsItem(GoodsItem goodsItem) throws DataAccessException {
		  goodsItemMapper.deleteGoodsItem(goodsItem);
	  }

}
