package com.example.jpetstore.domain;

public class Diary {
	
	private Account username; //�ܷ�Ű
	private String date;
	private String petName;
	private String celebrate; //�����
	private String memoId;
	private String memo;
	private String diaryId;
	
	
	
	public Account getUsername() {
		return username;
	}

	public void setUsername(Account username) {
		this.username = username;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getCelebrate() {
		return celebrate;
	}

	public void setCelebrate(String celebrate) {
		this.celebrate = celebrate;
	}

	public String getMemoId() {
		return memoId;
	}

	public void setMemoId(String memoId) {
		this.memoId = memoId;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getDiaryId() {
		return diaryId;
	}

	public void setDiaryId(String diaryId) {
		this.diaryId = diaryId;
	}

	public Diary() {
		
	}
	
	public void addCelebrate() {
		
	}
	
	public void removeCelebrate() {
		
	}
	
	

}
