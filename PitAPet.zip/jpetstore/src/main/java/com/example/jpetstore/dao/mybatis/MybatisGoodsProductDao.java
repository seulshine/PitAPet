package com.example.jpetstore.dao.mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.example.jpetstore.dao.mybatis.mapper.GoodsProductMapper;
import com.example.jpetstore.domain.GoodsProduct;

@Repository
public class MybatisGoodsProductDao {

	@Autowired
	private GoodsProductMapper goodsProductMapper;
	// ī�װ����� �´� ��ǰ ��������
	public List<GoodsProduct> getGoodsProductListByCategory(String goodsCategoryId) throws DataAccessException {
		return goodsProductMapper.getGoodsProductListByCategory(goodsCategoryId);
	}


	//�˻��� �� ���
	public List<GoodsProduct> searchGoodsProductList(String keywords) throws DataAccessException {
		return goodsProductMapper.searchGoodsProductList(keywords);
	}

	// ��ǰ ������ Ȯ��
	public GoodsProduct getGoodsProduct(String goodsProductId) throws DataAccessException {
		return goodsProductMapper.getGoodsProduct(goodsProductId);
	}

}
