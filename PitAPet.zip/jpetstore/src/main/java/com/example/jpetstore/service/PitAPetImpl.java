package com.example.jpetstore.service;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.jpetstore.dao.*;
import com.example.jpetstore.dao.AccountDao;
import com.example.jpetstore.dao.CategoryDao;
import com.example.jpetstore.dao.ItemDao;
import com.example.jpetstore.dao.OrderDao;
import com.example.jpetstore.dao.ProductDao;
import com.example.jpetstore.domain.Account;
import com.example.jpetstore.domain.Auction;
import com.example.jpetstore.domain.Category;
import com.example.jpetstore.domain.Coupon;
import com.example.jpetstore.domain.Diary;
import com.example.jpetstore.domain.GoodsItem;
import com.example.jpetstore.domain.GoodsProduct;
import com.example.jpetstore.domain.Item;
import com.example.jpetstore.domain.Note;
import com.example.jpetstore.domain.Order;
import com.example.jpetstore.domain.Product;
import com.example.jpetstore.domain.Bid;

@Service
@Transactional
public class PitAPetImpl implements PitAPetFacade { 
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private CategoryDao categoryDao; // ���� ī�װ��� / ��ǰ ī�װ���  (���� ���)
	@Autowired
	private ProductDao productDao; // ī�װ����� �´� ��������Ʈ
	
	@Autowired
	private ItemDao itemDao; // ���� ��������

	@Autowired
	private AuctionDao auctionDao; // ���� ��� 
	
	
	@Autowired
	private OrderDao orderDao; // ���� �ֹ�
	@Autowired
	private CartDao cartDao; // ��ǰ īƮ (���̺� �߰��ؾ���)
	@Autowired
	private GoodsItemDao goodsItemDao; // ���� ��������
	@Autowired
	private GoodsProductDao goodsProductDao; // ���� ������ ������
	
	@Autowired
	private DiaryDao diaryDao; 
	@Autowired
	private CouponDao couponDao;
	@Autowired
	private NoteDao noteDao;
	
	
	//-------------------------------------------------------------------------
	// Operation methods, implementing the PetStoreFacade interface
	//-------------------------------------------------------------------------

	public Account getAccount(String username) {
		return accountDao.getAccount(username);
	}

	public Account getAccount(String username, String password) {
		return accountDao.getAccount(username, password);
	}

	public void insertAccount(Account account) throws DataAccessException {
		accountDao.insertAccount(account);
	}
	public void updateAccount(Account account) throws DataAccessException {
		accountDao.updateAccount(account);
	}
	public void deleteAccount(Account account) throws DataAccessException {
		accountDao.deleteAccount(account);
	}
	public List<String> getUsernameList() throws DataAccessException {
		return accountDao.getUsernameList();
	}
	public List<Category> getCategoryList() throws DataAccessException {
		return categoryDao.getCategoryList();
	}
	public Category getCategory(String categoryId) throws DataAccessException {
		return categoryDao.getCategory(categoryId);
	}
	public List<Product> getProductListByCategory(String CategoryId) throws DataAccessException {
		return productDao.getProductListByCategory(CategoryId);
	}
	public List<Product> searchProductList(String keywords) throws DataAccessException {
		return productDao.searchProductList(keywords);
	}
	public Product getProduct(String ProductId) throws DataAccessException {
		return productDao.getProduct(ProductId);
	}
	
	public boolean isItemInStock(String itemId) throws DataAccessException {
		return itemDao.isItemInStock(itemId);
	}

	public List<Item> getItemListByProduct(String productId) throws DataAccessException {
		return itemDao.getItemListByProduct(productId);
	}

	public Item getItem(String itemId) throws DataAccessException {
		return itemDao.getItem(itemId);
	}
	
	@Override
	public void insertItem(Item item) throws DataAccessException {
		itemDao.insertItem(item);
	}

	@Override
	public void deleteItem(Item item) throws DataAccessException {
		itemDao.deleteItem(item);
	}
	
	public List<Auction> getAuctionsByCategoryId(String categoryId) throws DataAccessException {
		return auctionDao.getAuctionsByCategoryId(categoryId);
	}
	public List<Auction> getAuctionsByProductId(String categoryId, String ProductId) throws DataAccessException {
		return auctionDao.getAuctionsByProductId(categoryId, ProductId);
	}
	public List<Auction> getMadeAuctionsByUsername(String username) throws DataAccessException {
		return auctionDao.getMadeAuctionsByUsername(username);
	}
	public Auction getMadeAuction(int auctionId, String username) throws DataAccessException {
		return auctionDao.getMadeAuction(auctionId, username);
	}
	public void makeAuction(Auction auction) throws DataAccessException {
		auctionDao.makeAuction(auction);
	}
	public void deleteAuction(Auction auction) throws DataAccessException {
		auctionDao.deleteAuction(auction);
	}
	public List<Auction> getTendersByUsername(String username) throws DataAccessException {
		return auctionDao.getTendersByUsername(username);
	}
	public Auction getTenders(int auctionId) throws DataAccessException {
		return auctionDao.getTenders(auctionId);
	}
	public void insertTender(Bid tender) throws DataAccessException {
		auctionDao.insertTender(tender);
	}
	public List<Order> getOrdersByUsername(String username) throws DataAccessException {
		return orderDao.getOrdersByUsername(username);
	}
	public Order getOrder(int orderId) throws DataAccessException {
		return orderDao.getOrder(orderId);
	}
	public void insertOrder(Order order, String username) throws DataAccessException {
		orderDao.insertOrder(order, username);
	}
	public void deleteOrder(Order order) throws DataAccessException {
		orderDao.deleteOrder(order);
	}
	public List<GoodsItem> getGoodsItemByUsername(String username) throws DataAccessException {
		return cartDao.getGoodsItemByUsername(username);
	}
	public void insertItemToCart(Item item, String username) throws DataAccessException {
		cartDao.insertItemToCart(item, username);
	}
	public void deleteItemInCart(Item item, String username) throws DataAccessException {
		cartDao.deleteItemInCart(item, username);
	}
	public void updateInventoryQuantity(Map order) throws DataAccessException {
		goodsItemDao.updateInventoryQuantity(order);
	}
	public int getInventoryQuantity(String itemId) {
		return goodsItemDao.getInventoryQuantity(itemId);
	}
	
	@Override
	public GoodsItem getGoodsItem(String goodsItemId) throws DataAccessException {
		return goodsItemDao.getyGoodsItem(goodsItemId);
	}

	@Override
	public void insertGoodsItemToCart(GoodsItem goodsItem, String username) {
		goodsItemDao.insertGoodsItem(goodsItem);
		
	}

	@Override
	public void deleteGoodsItemInCart(GoodsItem goodsItem, String username) {
		goodsItemDao.deleteGoodsItem(goodsItem);
	}

	
	public List<GoodsItem> getGoodsItemListByProduct(String goodsProductId) throws DataAccessException {
		return goodsItemDao.getGoodsItemListByProduct(goodsProductId);
	}
	public GoodsItem getyGoodsItem(String goodsItemId) throws DataAccessException {
		return goodsItemDao.getyGoodsItem(goodsItemId);
	}
	public void insertGoodsItem(GoodsItem goodsItem) throws DataAccessException {
		goodsItemDao.insertGoodsItem(goodsItem);
	}
	public void deleteGoodsItem(GoodsItem goodsItem) throws DataAccessException {
		goodsItemDao.deleteGoodsItem(goodsItem);
	}
	public List<GoodsProduct> getGoodsProductListByCategory(String goodsCategoryId) throws DataAccessException {
		return goodsProductDao.getGoodsProductListByCategory(goodsCategoryId);
	}
	public List<GoodsProduct> searchGoodsProductList(String keywords) throws DataAccessException {
		return goodsProductDao.searchGoodsProductList(keywords);
	}
	public GoodsProduct getGoodsProduct(String goodsProductId) throws DataAccessException {
		return goodsProductDao.getGoodsProduct(goodsProductId);
	}
	public Diary getDiary(String username, String petname, String date) throws DataAccessException {
		return diaryDao.getDiary(username, petname, date);
	}
	public void insertDiaryList(String petName, String diaryTitle, String username) throws DataAccessException {
		diaryDao.insertDiaryList(petName, diaryTitle, username);
	}
	public List<Diary> getDiaryList(String username) throws DataAccessException {
		return diaryDao.getDiaryList(username);
	}
	public void insertDiary(Diary diary, String username, String petname) throws DataAccessException {
		diaryDao.insertDiary(diary, username, petname);
	}
	public void updateDiary(Diary diary, String username, String petname) throws DataAccessException {
		diaryDao.updateDiary(diary, username, petname);
	}
	public void deleteDiary(Diary diary, String username) throws DataAccessException {
		diaryDao.deleteDiary(diary, username);
	}
	public Coupon getCoupon(String username, String couponId) throws DataAccessException {
		return couponDao.getCoupon(username, couponId);
	}
	public void issueCoupon(Coupon coupon, String username) throws DataAccessException {
		couponDao.issueCoupon(coupon, username);
	}
	public void deleteCoupon(String couponId, String username) throws DataAccessException {
		couponDao.deleteCoupon(couponId, username);
	}
	public List<Coupon> getCouponList(String username) throws DataAccessException {
		return couponDao.getCouponList(username);
	}
	public void sendNote(Note note) throws DataAccessException {
		noteDao.sendNote(note);
	}
	public void deleteNote(String noteId, String username) throws DataAccessException {
		noteDao.deleteNote(noteId, username);
	}
	public List<Note> getNoteList(String username) throws DataAccessException {
		return noteDao.getNoteList(username);
	}
	public void selectNote(String noteId, String username) throws DataAccessException {
		noteDao.selectNote(noteId, username);
	}
	public List<Note> searchNoteList(String username) throws DataAccessException {
		return noteDao.searchNoteList(username);
	}

}